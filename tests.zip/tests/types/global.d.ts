declare global {
  var testDb: import('mysql2/promise').Connection;
}

export {};